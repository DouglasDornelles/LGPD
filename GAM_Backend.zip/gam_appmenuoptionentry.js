/*
               File: GAM_AppMenuOptionEntry
        Description: GAMExample App Menu Option Entry
             Author: GeneXus .NET Framework Generator version 17_0_11-163677
       Generated on: 8/31/2022 2:2:41.53
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_appmenuoptionentry', false, function () {
   this.ServerClass =  "gam_appmenuoptionentry" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_appmenuoptionentry.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV10ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV22MenuId=gx.fn.getIntegerValue("vMENUID",gx.thousandSeparator) ;
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.AV18Id=gx.fn.getIntegerValue("vID",gx.thousandSeparator) ;
      this.AV6isOK=gx.fn.getControlValue("vISOK") ;
   };
   this.Validv_Type=function()
   {
      return this.validCliEvt("Validv_Type", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV37Type , "S" ) == 0 || gx.text.compare( this.AV37Type , "M" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e122j2_client=function()
   {
      /* Type_Click Routine */
      return this.executeServerEvent("VTYPE.CLICK", true, null, false, true);
   };
   this.e132j2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e142j2_client=function()
   {
      /* Relresid_Controlvaluechanged Routine */
      return this.executeServerEvent("VRELRESID.CONTROLVALUECHANGED", true, null, false, true);
   };
   this.e162j1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72];
   this.GXLastCtrlId =72;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE3",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"TABLE2",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id:20 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAME",fmt:0,gxz:"ZV41GXV1",gxold:"OV41GXV1",gxvar:"GXV1",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV1=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV41GXV1=Value},v2c:function(){gx.fn.setControlValue("CTLNAME",gx.O.GXV1,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV1=this.val()},val:function(){return gx.fn.getControlValue("CTLNAME")},nac:gx.falseFn};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAMEMENU",fmt:0,gxz:"ZV42GXV2",gxold:"OV42GXV2",gxvar:"GXV2",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV2=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV42GXV2=Value},v2c:function(){gx.fn.setControlValue("CTLNAMEMENU",gx.O.GXV2,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV2=this.val()},val:function(){return gx.fn.getControlValue("CTLNAMEMENU")},nac:gx.falseFn};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id:30 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",fmt:0,gxz:"ZV17GUID",gxold:"OV17GUID",gxvar:"AV17GUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV17GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17GUID=Value},v2c:function(){gx.fn.setControlValue("vGUID",gx.O.AV17GUID,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV17GUID=this.val()},val:function(){return gx.fn.getControlValue("vGUID")},nac:gx.falseFn};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV25Name",gxold:"OV25Name",gxvar:"AV25Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV25Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV25Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 35 , function() {
   });
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id:40 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV13Dsc",gxold:"OV13Dsc",gxvar:"AV13Dsc",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV13Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13Dsc=Value},v2c:function(){gx.fn.setControlValue("vDSC",gx.O.AV13Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13Dsc=this.val()},val:function(){return gx.fn.getControlValue("vDSC")},nac:gx.falseFn};
   this.declareDomainHdlr( 40 , function() {
   });
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id:45 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Type,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTYPE",fmt:0,gxz:"ZV37Type",gxold:"OV37Type",gxvar:"AV37Type",ucs:[],op:[45],ip:[45],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV37Type=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV37Type=Value},v2c:function(){gx.fn.setComboBoxValue("vTYPE",gx.O.AV37Type);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV37Type=this.val()},val:function(){return gx.fn.getControlValue("vTYPE")},nac:gx.falseFn,evt:"e122j2_client"};
   this.declareDomainHdlr( 45 , function() {
   });
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"MENUSCELL",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id:50 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMENUSID",fmt:0,gxz:"ZV24MenusId",gxold:"OV24MenusId",gxvar:"AV24MenusId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV24MenusId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV24MenusId=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vMENUSID",gx.O.AV24MenusId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV24MenusId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vMENUSID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 50 , function() {
   });
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"PERMISSIONCELL",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id:55 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e142j2_client',evt_cvcing:null,rgrid:[],fld:"vRELRESID",fmt:0,gxz:"ZV32RelResId",gxold:"OV32RelResId",gxvar:"AV32RelResId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV32RelResId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV32RelResId=Value},v2c:function(){gx.fn.setComboBoxValue("vRELRESID",gx.O.AV32RelResId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV32RelResId=this.val()},val:function(){return gx.fn.getControlValue("vRELRESID")},nac:gx.falseFn};
   this.declareDomainHdlr( 55 , function() {
   });
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"RESOURCECELL",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id:60 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vRESOURCE",fmt:0,gxz:"ZV34Resource",gxold:"OV34Resource",gxvar:"AV34Resource",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV34Resource=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV34Resource=Value},v2c:function(){gx.fn.setControlValue("vRESOURCE",gx.O.AV34Resource,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV34Resource=this.val()},val:function(){return gx.fn.getControlValue("vRESOURCE")},nac:gx.falseFn};
   this.declareDomainHdlr( 60 , function() {
   });
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"RESOURCEPARAMETERSCELL",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id:65 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vRESOURCEPARAMETERS",fmt:0,gxz:"ZV35ResourceParameters",gxold:"OV35ResourceParameters",gxvar:"AV35ResourceParameters",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV35ResourceParameters=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV35ResourceParameters=Value},v2c:function(){gx.fn.setControlValue("vRESOURCEPARAMETERS",gx.O.AV35ResourceParameters,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV35ResourceParameters=this.val()},val:function(){return gx.fn.getControlValue("vRESOURCEPARAMETERS")},nac:gx.falseFn};
   this.declareDomainHdlr( 65 , function() {
   });
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"BRNCANCEL",grid:0,evt:"e162j1_client"};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"BTNCONFIRM",grid:0,evt:"e132j2_client",std:"ENTER"};
   this.GXV1 = "" ;
   this.ZV41GXV1 = "" ;
   this.OV41GXV1 = "" ;
   this.GXV2 = "" ;
   this.ZV42GXV2 = "" ;
   this.OV42GXV2 = "" ;
   this.AV17GUID = "" ;
   this.ZV17GUID = "" ;
   this.OV17GUID = "" ;
   this.AV25Name = "" ;
   this.ZV25Name = "" ;
   this.OV25Name = "" ;
   this.AV13Dsc = "" ;
   this.ZV13Dsc = "" ;
   this.OV13Dsc = "" ;
   this.AV37Type = "" ;
   this.ZV37Type = "" ;
   this.OV37Type = "" ;
   this.AV24MenusId = 0 ;
   this.ZV24MenusId = 0 ;
   this.OV24MenusId = 0 ;
   this.AV32RelResId = "" ;
   this.ZV32RelResId = "" ;
   this.OV32RelResId = "" ;
   this.AV34Resource = "" ;
   this.ZV34Resource = "" ;
   this.OV34Resource = "" ;
   this.AV35ResourceParameters = "" ;
   this.ZV35ResourceParameters = "" ;
   this.OV35ResourceParameters = "" ;
   this.GXV1 = "" ;
   this.GXV2 = "" ;
   this.AV17GUID = "" ;
   this.AV25Name = "" ;
   this.AV13Dsc = "" ;
   this.AV37Type = "" ;
   this.AV24MenusId = 0 ;
   this.AV32RelResId = "" ;
   this.AV34Resource = "" ;
   this.AV35ResourceParameters = "" ;
   this.AV10ApplicationId = 0 ;
   this.AV22MenuId = 0 ;
   this.AV18Id = 0 ;
   this.Gx_mode = "" ;
   this.AV6isOK = false ;
   this.AV5GAMApplication = {} ;
   this.AV11ApplicationMenu = {} ;
   this.Events = {"e122j2_client": ["VTYPE.CLICK", true] ,"e132j2_client": ["ENTER", true] ,"e142j2_client": ["VRELRESID.CONTROLVALUECHANGED", true] ,"e162j1_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV10ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV22MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true},{av:'AV18Id',fld:'vID',pic:'ZZZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["VTYPE.CLICK"] = [[{ctrl:'vTYPE'},{av:'AV37Type',fld:'vTYPE',pic:''},{ctrl:'vRELRESID'},{av:'AV32RelResId',fld:'vRELRESID',pic:''},{av:'AV10ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{ctrl:'vMENUSID'},{av:'AV24MenusId',fld:'vMENUSID',pic:'ZZZZZZZZZZZ9'},{av:'AV22MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9',hsh:true}],[{ctrl:'vRELRESID'},{av:'AV32RelResId',fld:'vRELRESID',pic:''},{ctrl:'vMENUSID'},{av:'AV24MenusId',fld:'vMENUSID',pic:'ZZZZZZZZZZZ9'},{av:'gx.fn.getCtrlProperty("MENUSCELL","Visible")',ctrl:'MENUSCELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("RESOURCECELL","Visible")',ctrl:'RESOURCECELL',prop:'Visible'}]];
   this.EvtParms["ENTER"] = [[{av:'AV10ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV25Name',fld:'vNAME',pic:''},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true},{av:'AV22MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV18Id',fld:'vID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV6isOK',fld:'vISOK',pic:''},{av:'AV17GUID',fld:'vGUID',pic:''},{av:'AV13Dsc',fld:'vDSC',pic:''},{ctrl:'vTYPE'},{av:'AV37Type',fld:'vTYPE',pic:''},{ctrl:'vMENUSID'},{av:'AV24MenusId',fld:'vMENUSID',pic:'ZZZZZZZZZZZ9'},{ctrl:'vRELRESID'},{av:'AV32RelResId',fld:'vRELRESID',pic:''},{av:'AV34Resource',fld:'vRESOURCE',pic:''},{av:'AV35ResourceParameters',fld:'vRESOURCEPARAMETERS',pic:''}],[{av:'AV6isOK',fld:'vISOK',pic:''}]];
   this.EvtParms["VRELRESID.CONTROLVALUECHANGED"] = [[{av:'AV34Resource',fld:'vRESOURCE',pic:''},{av:'AV10ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{ctrl:'vRELRESID'},{av:'AV32RelResId',fld:'vRELRESID',pic:''}],[{av:'AV34Resource',fld:'vRESOURCE',pic:''}]];
   this.EvtParms["VALIDV_TYPE"] = [[],[]];
   this.EnterCtrl = ["BTNCONFIRM"];
   this.setVCMap("AV10ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV22MenuId", "vMENUID", 0, "int", 12, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV18Id", "vID", 0, "int", 12, 0);
   this.setVCMap("AV6isOK", "vISOK", 0, "boolean", 4, 0);
   this.addBCProperty("Gamapplication", ["Name"], this.GXValidFnc[20], "AV5GAMApplication");
   this.addBCProperty("Applicationmenu", ["Name"], this.GXValidFnc[25], "AV11ApplicationMenu");
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_appmenuoptionentry);});
