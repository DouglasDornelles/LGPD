/*
               File: GAM_UpdateRegisterUser
        Description: Update register user
             Author: GeneXus .NET Framework Generator version 17_0_11-163677
       Generated on: 8/31/2022 2:2:16.8
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_updateregisteruser', false, function () {
   this.ServerClass =  "gam_updateregisteruser" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_updateregisteruser.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV18IDP_State=gx.fn.getControlValue("vIDP_STATE") ;
   };
   this.Validv_Birthday=function()
   {
      return this.validCliEvt("Validv_Birthday", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vBIRTHDAY");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV6Birthday)===0) || new gx.date.gxdate( this.AV6Birthday ).compare( gx.date.ymdtod( 1753, 1, 1) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "BIRTHDAT"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Gender=function()
   {
      return this.validCliEvt("Validv_Gender", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vGENDER");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV11Gender , "N" ) == 0 || gx.text.compare( this.AV11Gender , "F" ) == 0 || gx.text.compare( this.AV11Gender , "M" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "GENDER"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e121i2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e131i2_client=function()
   {
      /* 'ReturnToLogin' Routine */
      return this.executeServerEvent("'RETURNTOLOGIN'", false, null, false, false);
   };
   this.e151i2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52];
   this.GXLastCtrlId =52;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE3",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"TABLE2",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"TBTITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id:20 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV14Name",gxold:"OV14Name",gxvar:"AV14Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV14Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 20 , function() {
   });
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"svchar",len:100,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAIL",fmt:0,gxz:"ZV7EMail",gxold:"OV7EMail",gxvar:"AV7EMail",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV7EMail=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7EMail=Value},v2c:function(){gx.fn.setControlValue("vEMAIL",gx.O.AV7EMail,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV7EMail=this.val()},val:function(){return gx.fn.getControlValue("vEMAIL")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id:30 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFIRSTNAME",fmt:0,gxz:"ZV10FirstName",gxold:"OV10FirstName",gxvar:"AV10FirstName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10FirstName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10FirstName=Value},v2c:function(){gx.fn.setControlValue("vFIRSTNAME",gx.O.AV10FirstName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10FirstName=this.val()},val:function(){return gx.fn.getControlValue("vFIRSTNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 30 , function() {
   });
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLASTNAME",fmt:0,gxz:"ZV13LastName",gxold:"OV13LastName",gxvar:"AV13LastName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV13LastName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13LastName=Value},v2c:function(){gx.fn.setControlValue("vLASTNAME",gx.O.AV13LastName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13LastName=this.val()},val:function(){return gx.fn.getControlValue("vLASTNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 35 , function() {
   });
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id:40 ,lvl:0,type:"date",len:10,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Birthday,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBIRTHDAY",fmt:0,gxz:"ZV6Birthday",gxold:"OV6Birthday",gxvar:"AV6Birthday",dp:{f:0,st:false,wn:false,mf:false,pic:"99/99/9999",dec:0},ucs:[],op:[40],ip:[40],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV6Birthday=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV6Birthday=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vBIRTHDAY",gx.O.AV6Birthday,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV6Birthday=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getControlValue("vBIRTHDAY")},nac:gx.falseFn};
   this.declareDomainHdlr( 40 , function() {
   });
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id:45 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Gender,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGENDER",fmt:0,gxz:"ZV11Gender",gxold:"OV11Gender",gxvar:"AV11Gender",ucs:[],op:[45],ip:[45],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV11Gender=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11Gender=Value},v2c:function(){gx.fn.setComboBoxValue("vGENDER",gx.O.AV11Gender);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11Gender=this.val()},val:function(){return gx.fn.getControlValue("vGENDER")},nac:gx.falseFn};
   this.declareDomainHdlr( 45 , function() {
   });
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"BUTTON1",grid:0,evt:"e131i2_client"};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"BUTTON2",grid:0,evt:"e121i2_client",std:"ENTER"};
   this.AV14Name = "" ;
   this.ZV14Name = "" ;
   this.OV14Name = "" ;
   this.AV7EMail = "" ;
   this.ZV7EMail = "" ;
   this.OV7EMail = "" ;
   this.AV10FirstName = "" ;
   this.ZV10FirstName = "" ;
   this.OV10FirstName = "" ;
   this.AV13LastName = "" ;
   this.ZV13LastName = "" ;
   this.OV13LastName = "" ;
   this.AV6Birthday = gx.date.nullDate() ;
   this.ZV6Birthday = gx.date.nullDate() ;
   this.OV6Birthday = gx.date.nullDate() ;
   this.AV11Gender = "" ;
   this.ZV11Gender = "" ;
   this.OV11Gender = "" ;
   this.AV14Name = "" ;
   this.AV7EMail = "" ;
   this.AV10FirstName = "" ;
   this.AV13LastName = "" ;
   this.AV6Birthday = gx.date.nullDate() ;
   this.AV11Gender = "" ;
   this.AV18IDP_State = "" ;
   this.Events = {"e121i2_client": ["ENTER", true] ,"e131i2_client": ["'RETURNTOLOGIN'", true] ,"e151i2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV18IDP_State',fld:'vIDP_STATE',pic:'',hsh:true}],[]];
   this.EvtParms["ENTER"] = [[{av:'AV14Name',fld:'vNAME',pic:''},{av:'AV7EMail',fld:'vEMAIL',pic:''},{av:'AV10FirstName',fld:'vFIRSTNAME',pic:''},{av:'AV13LastName',fld:'vLASTNAME',pic:''},{av:'AV6Birthday',fld:'vBIRTHDAY',pic:''},{ctrl:'vGENDER'},{av:'AV11Gender',fld:'vGENDER',pic:''},{av:'AV18IDP_State',fld:'vIDP_STATE',pic:'',hsh:true}],[]];
   this.EvtParms["'RETURNTOLOGIN'"] = [[],[]];
   this.EvtParms["VALIDV_BIRTHDAY"] = [[],[]];
   this.EvtParms["VALIDV_GENDER"] = [[],[]];
   this.EnterCtrl = ["BUTTON2"];
   this.setVCMap("AV18IDP_State", "vIDP_STATE", 0, "char", 60, 0);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_updateregisteruser);});
