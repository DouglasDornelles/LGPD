/*
               File: GAM_WWConnections
        Description: Connections
             Author: GeneXus .NET Framework Generator version 17_0_11-163677
       Generated on: 8/31/2022 2:0:50.89
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwconnections', false, function () {
   this.ServerClass =  "gam_wwconnections" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwconnections.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e140g2_client=function()
   {
      /* Name_Click Routine */
      this.clearMessages();
      this.call("gam_connectionentry.aspx", ["DSP", this.AV8Name], null, ["Mode","pConnectionName"]);
      this.refreshOutputs([{av:'AV8Name',fld:'vNAME',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e110g2_client=function()
   {
      /* 'AddNew' Routine */
      return this.executeServerEvent("'ADDNEW'", false, null, false, false);
   };
   this.e130g2_client=function()
   {
      /* Btnupd_Click Routine */
      return this.executeServerEvent("VBTNUPD.CLICK", true, arguments[0], false, false);
   };
   this.e150g2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e160g2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,24,25,26];
   this.GXLastCtrlId =26;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",23,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwconnections",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",24,"vNAME",gx.getMessage( "Connection Name"),"","Name","char",0,"px",254,80,"left","e140g2_client",[],"Name","Name",true,0,false,false,"Attribute",1,"WWColumn");
   GridwwContainer.addSingleLineEdit("Username",25,"vUSERNAME",gx.getMessage( "User Name"),"","UserName","char",0,"px",254,80,"left",null,[],"Username","UserName",true,0,false,false,"Attribute",1,"WWColumn WWSecondaryColumn");
   GridwwContainer.addSingleLineEdit("Btnupd",26,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"left","e130g2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLETOP",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"ADDNEW1",grid:0,evt:"e110g2_client"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id:14 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV10Search",gxold:"OV10Search",gxvar:"AV10Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV10Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 14 , function() {
   });
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"TABLE1",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV8Name",gxold:"OV8Name",gxvar:"AV8Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV8Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(23),gx.O.AV8Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e140g2_client"};
   GXValidFnc[25]={ id:25 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERNAME",fmt:0,gxz:"ZV11UserName",gxold:"OV11UserName",gxvar:"AV11UserName",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11UserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11UserName=Value},v2c:function(row){gx.fn.setGridControlValue("vUSERNAME",row || gx.fn.currentGridRowImpl(23),gx.O.AV11UserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11UserName=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vUSERNAME",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",fmt:0,gxz:"ZV5BtnUpd",gxold:"OV5BtnUpd",gxvar:"AV5BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23),gx.O.AV5BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e130g2_client"};
   this.AV10Search = "" ;
   this.ZV10Search = "" ;
   this.OV10Search = "" ;
   this.ZV8Name = "" ;
   this.OV8Name = "" ;
   this.ZV11UserName = "" ;
   this.OV11UserName = "" ;
   this.ZV5BtnUpd = "" ;
   this.OV5BtnUpd = "" ;
   this.AV10Search = "" ;
   this.AV8Name = "" ;
   this.AV11UserName = "" ;
   this.AV5BtnUpd = "" ;
   this.Events = {"e110g2_client": ["'ADDNEW'", true] ,"e130g2_client": ["VBTNUPD.CLICK", true] ,"e150g2_client": ["ENTER", true] ,"e160g2_client": ["CANCEL", true] ,"e140g2_client": ["VNAME.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV10Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV10Search',fld:'vSEARCH',pic:''}],[{av:'AV5BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV11UserName',fld:'vUSERNAME',pic:''},{av:'AV8Name',fld:'vNAME',pic:''}]];
   this.EvtParms["'ADDNEW'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV10Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'AV8Name',fld:'vNAME',pic:''}],[{av:'AV8Name',fld:'vNAME',pic:''}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV10Search',fld:'vSEARCH',pic:''},{av:'AV8Name',fld:'vNAME',pic:''}],[{av:'AV8Name',fld:'vNAME',pic:''}]];
   this.EvtParms["ENTER"] = [[],[]];
   GridwwContainer.addRefreshingVar(this.GXValidFnc[14]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[14]);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_wwconnections);});
