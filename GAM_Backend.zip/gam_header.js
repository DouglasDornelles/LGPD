/*
               File: GAM_Header
        Description: GAM_Header
             Author: GeneXus .NET Framework Generator version 17_0_11-163677
       Generated on: 8/31/2022 2:0:3.54
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_header', true, function (CmpContext) {
   this.ServerClass =  "gam_header" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_header.aspx" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV5AactualPage=gx.fn.getControlValue("vAACTUALPAGE") ;
   };
   this.e11291_client=function()
   {
      /* 'GoHome' Routine */
      this.clearMessages();
      this.call("gam_dashboard.aspx", [], null, []);
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e14292_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e15292_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34];
   this.GXLastCtrlId =34;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK3", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"TEXTBLOCK4", format:0,grid:0,evt:"e11291_client", ctrltype: "textblock"};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[17]={ id: 17, fld:"MENU_INNER",grid:0};
   GXValidFnc[18]={ id: 18, fld:"TBMENUUSERS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[19]={ id: 19, fld:"TBMENUROLES", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[20]={ id: 20, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"WWSECPOL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[22]={ id: 22, fld:"WWAPPLICATIONS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"REPOSITORYCONFIGURATION", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[24]={ id: 24, fld:"WWREPOSITORYCONNECTIONS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[25]={ id: 25, fld:"WWAUTHENTICATIONTYPES", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[26]={ id: 26, fld:"CHANGEPASSWORD", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[27]={ id: 27, fld:"CHANGEWORKREPOSITORY", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[28]={ id: 28, fld:"WWREPOSITORIES", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[29]={ id: 29, fld:"WWEVENTS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[30]={ id: 30, fld:"GAMCONFIGURATION", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"TABLE2",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   this.AV5AactualPage = "" ;
   this.Events = {"e14292_client": ["ENTER", true] ,"e15292_client": ["CANCEL", true] ,"e11291_client": ["'GOHOME'", false]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["'GOHOME'"] = [[],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV5AactualPage", "vAACTUALPAGE", 0, "char", 50, 0);
   this.Initialize( );
   this.setComponent({id: "COMPONENT2" ,GXClass: "gam_logout" , Prefix: "W0035" , lvl: 1 });
});
